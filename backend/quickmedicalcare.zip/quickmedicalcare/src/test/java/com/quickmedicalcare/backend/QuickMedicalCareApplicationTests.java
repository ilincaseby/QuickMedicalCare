package com.quickmedicalcare.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickMedicalCareApplicationTests {

	@Test
	void contextLoads() {
	}

}
